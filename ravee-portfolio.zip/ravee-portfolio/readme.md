# Ravee Bhatt — Portfolio

A multi-page personal portfolio focused on brand strategy,
social media thinking, and editorial storytelling.

Built with:
- HTML
- CSS
- Vanilla JavaScript
- GitHub Pages

Designed to feel personal, strategic, and intentional.
